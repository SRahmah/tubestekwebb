Login Sebagai Admin
Username : admin
Password : admin

Login Sebagai Kasir
Username : KSR58
Password : Vanisa